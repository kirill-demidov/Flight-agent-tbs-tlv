import { useState, useEffect } from "react";

const AIRLINES_META = {
  "Georgian Airways": {
    code: "A9", color: "#e8c53a",
    bookingUrl: "https://flights.georgian-airways.com/en/",
    baggageUrl: "https://georgian-airways.com/en/service/baggage-information",
    status: "❓ Иностранный перевозчик — статус под вопросом",
    bagNote: "STANDARD: 1×23кг включён. LIGHT: без багажа.",
  },
  "El Al": {
    code: "LY", color: "#4da6ff",
    bookingUrl: "https://www.elal.com/eng/",
    baggageUrl: "https://www.elal.com/eng/baggage/baggage-allowance",
    status: "⚠️ Аварийное расписание до 18.04.2026",
    bagNote: "1×23кг включён в эконом.",
  },
  "Arkia": {
    code: "IZ", color: "#ff6b6b",
    bookingUrl: "https://www.arkia.com/en/",
    baggageUrl: "https://www.arkia.com/en/content/customer-service-plans",
    status: "🔴 Продажи приостановлены до ~25.04.2026",
    bagNote: "1×23кг включён в эконом.",
  },
  "Israir": {
    code: "6H", color: "#51cf66",
    bookingUrl: "https://www.israir.co.il/en/",
    baggageUrl: "https://www.israir.co.il/en/",
    status: "✅ Летает",
    bagNote: "1×23кг включён в эконом.",
  },
};

function today() { return new Date().toISOString().split("T")[0]; }
function nextWeek() { const d = new Date(); d.setDate(d.getDate() + 7); return d.toISOString().split("T")[0]; }
function fmtDate(s) {
  return new Date(s + "T12:00:00").toLocaleDateString("ru-RU", { day: "numeric", month: "long", year: "numeric" });
}

function Counter({ value, onChange, min = 0 }) {
  return (
    <div style={s.counter}>
      <button style={s.cBtn} onClick={() => onChange(Math.max(min, value - 1))}>−</button>
      <span style={s.cVal}>{value}</span>
      <button style={s.cBtn} onClick={() => onChange(value + 1)}>+</button>
    </div>
  );
}

export default function App() {
  const [date, setDate]       = useState(nextWeek());
  const [pax, setPax]         = useState(4);
  const [large, setLarge]     = useState(2);
  const [trolleys, setTrolls] = useState(2);
  const [loading, setLoading] = useState(false);
  const [phase, setPhase]     = useState(0);
  const [result, setResult]   = useState(null);
  const [error, setError]     = useState(null);
  const [rawDebug, setRawDebug] = useState(null);

  const PHASES = [
    "Проверяю доску прилётов Ben Gurion…",
    "Ищу рейсы TBS→TLV на официальных сайтах…",
    "Считаю полную стоимость для вашей группы…",
  ];

  useEffect(() => {
    if (!loading) return;
    setPhase(0);
    const iv = setInterval(() => setPhase(p => Math.min(p + 1, PHASES.length - 1)), 2000);
    return () => clearInterval(iv);
  }, [loading]);

  const buildPrompt = () => `
Ты — авиационный агент. Найди рейс TBS (Тбилиси) → TLV (Тель-Авив) в одну сторону и рассчитай полную стоимость.

КОНТЕКСТ (обязательно учти):
С 28 февраля 2026 Израиль закрыл небо для иностранных авиакомпаний.
ЛЕТАЮТ ТОЛЬКО израильские: El Al (LY), Arkia (IZ), Israir (6H).
Georgian Airways (A9) — иностранный перевозчик, статус под вопросом.
Turkish, Wizz Air, FlyDubai, Emirates — НЕ летают.
Arkia приостановила продажи до ~25 апреля 2026.

ШАГ 1 — Проверь доску прилётов:
Используй web_search: "TLV arrivals TBS Tbilisi April 2026 landed El Al Israir Georgian Airways"
Найди факты о реальных прилётах из TBS за последние 5 дней.

ШАГ 2 — Найди цены ТОЛЬКО на официальных сайтах:
- Georgian Airways: flights.georgian-airways.com
- El Al: elal.com  
- Israir: israir.co.il
Используй web_search: "elal.com TBS TLV ${date} one way price" и аналогично для остальных.

ПАРАМЕТРЫ:
- Дата: ${fmtDate(date)} (${date})
- Направление: TBS → TLV, только туда (one way)
- Пассажиров: ${pax}
- Больших чемоданов 23кг: ${large}
- Троллей / ручной клади: ${trolleys}

ПРАВИЛА БАГАЖА (с официальных сайтов):
Georgian Airways STANDARD: 1×23кг включён + ручная кладь 8кг
Georgian Airways LIGHT: без багажа (нужно докупать ~$40/чемодан)
El Al эконом: 1×23кг включён + ручная кладь 8кг
Israir эконом: 1×23кг включён
Лишний чемодан: El Al ~$50, Georgian ~$40, Israir ~$35

РАСЧЁТ:
- На ${pax} пассажиров включено ${pax} чемоданов (по 1 на человека в STANDARD/эконом)
- Больших чемоданов заявлено: ${large}. Лишних: ${Math.max(0, large - pax)} шт.
- Троллей ${trolleys} шт — обычно входят в норму ручной клади 8кг, но уточни размер
- Посчитай: цена билета × ${pax} + стоимость лишнего багажа = итого

КРИТИЧЕСКИ ВАЖНО ДЛЯ ФОРМАТА:
- Ответь ТОЛЬКО валидным JSON объектом
- Никакого текста до или после JSON
- Никаких markdown блоков или кавычек вокруг JSON
- Все строки в двойных кавычках
- Никаких trailing comma
- Числа без кавычек (185, не "185")
- Булевы без кавычек (true/false, не "true")

ТОЧНАЯ СТРУКТУРА (заполни реальными данными):
{"arrivals":[{"flight":"LY361","date":"08.04.2026","status":"LANDED"}],"airlines":[{"name":"El Al","flying":true,"evidence":"текст","price_per_person":185,"fare":"Economy","bag_included":true,"source_url":"https://www.elal.com/"}],"best":{"airline":"El Al","price_per_person":185,"tickets_subtotal":740,"extra_bags":0,"extra_bags_cost":0,"trolleys_ok":true,"trolleys_note":"текст","total_usd":740,"total_ils":2738,"tip":"текст"},"warning":"текст"}`;

  const safeParseJSON = (text) => {
    const tries = [
      () => JSON.parse(text.trim()),
      () => JSON.parse(text.replace(/```json|```/gi, "").trim()),
      () => { const s = text.indexOf("{"), e = text.lastIndexOf("}"); return s !== -1 && e > s ? JSON.parse(text.slice(s, e + 1)) : null; },
    ];
    for (const fn of tries) { try { const r = fn(); if (r) return r; } catch {} }
    return null;
  };

  const search = async () => {
    setLoading(true);
    setResult(null);
    setError(null);
    setRawDebug(null);
    try {
      const res = await fetch("/api/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 2000,
          tools: [{ type: "web_search_20250305", name: "web_search" }],
          messages: [{ role: "user", content: buildPrompt() }],
        }),
      });
      const data = await res.json();
      const allText = (data.content || []).filter(b => b.type === "text").map(b => b.text).join("\n");
      const blockTypes = (data.content || []).map(b => b.type).join(", ");
      const parsed = safeParseJSON(allText);
      if (parsed) {
        setResult(parsed);
      } else {
        setRawDebug({
          stop_reason: data.stop_reason || "unknown",
          block_types: blockTypes,
          text_preview: allText.slice(0, 600) || "(пусто)",
          api_error: data.error ? JSON.stringify(data.error) : null,
        });
        setError("Не удалось разобрать ответ. Детали ниже ↓");
      }
    } catch (e) {
      setError("Сетевая ошибка: " + e.message);
    } finally {
      setLoading(false);
    }
  };

  const C = { bg:"#080b12", surf:"#0e1220", border:"#1a2035", accent:"#00c8ff", green:"#51cf66", yellow:"#ffd166", red:"#ff6b6b", text:"#dde1f0", muted:"#4a5270" };

  return (
    <div style={{ minHeight:"100vh", background:C.bg, color:C.text, fontFamily:"'IBM Plex Sans',sans-serif", padding:"20px 16px 60px", maxWidth:680, margin:"0 auto" }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&family=IBM+Plex+Sans:wght@300;400;500&display=swap'); *{box-sizing:border-box;margin:0;padding:0} input[type=date]::-webkit-calendar-picker-indicator{filter:invert(.5);cursor:pointer} a:hover{opacity:.8}`}</style>

      {/* Header */}
      <div style={{ marginBottom:16 }}>
        <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:20, fontWeight:600, letterSpacing:3, color:C.accent }}>✈ FLIGHT AGENT</div>
        <div style={{ fontSize:11, color:C.muted, letterSpacing:1.5, marginTop:2 }}>TBS → TLV · ONE WAY · Только официальные сайты авиакомпаний</div>
      </div>

      {/* War banner */}
      <div style={{ display:"flex", gap:10, background:"#ffd16610", border:`1px solid ${C.yellow}44`, borderRadius:10, padding:"12px 14px", marginBottom:14 }}>
        <span style={{ fontSize:18 }}>⚠️</span>
        <div>
          <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:10, color:C.yellow, letterSpacing:1, marginBottom:3 }}>ОГРАНИЧЕННОЕ НЕБО · АПРЕЛЬ 2026</div>
          <div style={{ fontSize:12, color:"#b0a060", lineHeight:1.5 }}>С 28.02.26 летают только израильские компании: El Al, Arkia, Israir. Иностранные авиакомпании (Georgian Airways, Turkish и др.) — под вопросом. Агент проверяет доску прилётов Ben Gurion как главный источник правды.</div>
        </div>
      </div>

      {/* Form */}
      <div style={{ background:C.surf, border:`1px solid ${C.border}`, borderRadius:14, padding:"18px 20px", marginBottom:14 }}>
        {/* Date */}
        <div style={{ marginBottom:14 }}>
          <div style={s.lbl}>ДАТА ВЫЛЕТА</div>
          <input type="date" value={date} min={today()} onChange={e => setDate(e.target.value)}
            style={{ background:C.bg, border:`1px solid ${C.border}`, borderRadius:7, padding:"10px 12px", color:C.text, fontSize:14, fontFamily:"'IBM Plex Sans',sans-serif", outline:"none", width:"100%" }} />
        </div>

        {/* Pax + bags */}
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:12, marginBottom:14 }}>
          <div>
            <div style={s.lbl}>ПАССАЖИРЫ</div>
            <Counter value={pax} onChange={setPax} min={1} />
          </div>
          <div>
            <div style={s.lbl}>🧳 ЧЕМОДАНЫ 23кг</div>
            <Counter value={large} onChange={setLarge} />
          </div>
          <div>
            <div style={s.lbl}>💼 ТРОЛЛИ</div>
            <Counter value={trolleys} onChange={setTrolls} />
          </div>
        </div>

        {/* Summary pill */}
        <div style={{ background:"#ffffff08", borderRadius:8, padding:"8px 12px", marginBottom:14, fontSize:12, color:"#a0a8c0", display:"flex", gap:8, flexWrap:"wrap" }}>
          <span>👥 {pax} чел.</span><span style={{ color:C.muted }}>·</span>
          <span>🧳 {large} чемодана</span><span style={{ color:C.muted }}>·</span>
          <span>💼 {trolleys} тролли</span><span style={{ color:C.muted }}>·</span>
          <span style={{ color: large > pax ? C.yellow : C.green }}>
            {large > pax ? `⚠️ ${large - pax} лишних чемодана — доплата` : "✓ чемоданы в норме включённого багажа"}
          </span>
        </div>

        <button onClick={search} disabled={loading}
          style={{ width:"100%", padding:"13px", background:`${C.accent}15`, border:`1px solid ${C.accent}`, borderRadius:9, color:C.accent, fontSize:12, fontFamily:"'IBM Plex Mono',monospace", letterSpacing:2, cursor:loading?"not-allowed":"pointer", opacity:loading?.7:1 }}>
          {loading ? "🔍 АНАЛИЗИРУЮ..." : "🔍 НАЙТИ РЕЙС И РАССЧИТАТЬ СТОИМОСТЬ"}
        </button>
      </div>

      {/* Loading */}
      {loading && (
        <div style={{ background:C.surf, border:`1px solid ${C.border}`, borderRadius:14, padding:"20px", marginBottom:14, textAlign:"center" }}>
          <div style={{ fontSize:24, marginBottom:10 }}>
            {["🔍","✈️","💰"][phase]}
          </div>
          <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:12, color:C.accent, letterSpacing:1 }}>
            {PHASES[phase]}
          </div>
          <div style={{ marginTop:12, display:"flex", gap:6, justifyContent:"center" }}>
            {PHASES.map((_, i) => (
              <div key={i} style={{ width:6, height:6, borderRadius:"50%", background: i <= phase ? C.accent : C.border, transition:"background .3s" }} />
            ))}
          </div>
        </div>
      )}

      {/* Error */}
      {error && (
        <div style={{ background:"#ff6b6b10", border:`1px solid ${C.red}44`, borderRadius:10, padding:"14px", color:C.red, fontSize:13, marginBottom:14 }}>
          {error}
        </div>
      )}

      {/* Debug panel */}
      {rawDebug && (
        <div style={{ background:"#0a0e1a", border:"1px solid #ff6b6b44", borderRadius:10, padding:"14px", marginBottom:14, fontSize:11, fontFamily:"monospace" }}>
          <div style={{ color:"#ff6b6b", marginBottom:8, fontWeight:600 }}>🔍 ДИАГНОСТИКА</div>
          <div style={{ color:"#888", marginBottom:4 }}>stop_reason: <span style={{ color:"#ffd166" }}>{rawDebug.stop_reason}</span></div>
          <div style={{ color:"#888", marginBottom:4 }}>блоки: <span style={{ color:"#ffd166" }}>{rawDebug.block_types}</span></div>
          {rawDebug.api_error && <div style={{ color:"#ff6b6b", marginBottom:4 }}>ошибка API: {rawDebug.api_error}</div>}
          <div style={{ color:"#888", marginBottom:4 }}>текст ответа:</div>
          <div style={{ color:"#a0c8a0", background:"#050810", padding:"8px", borderRadius:6, whiteSpace:"pre-wrap", wordBreak:"break-all", maxHeight:200, overflowY:"auto" }}>
            {rawDebug.text_preview}
          </div>
        </div>
      )}

      {/* Results */}
      {result && (
        <div style={{ display:"flex", flexDirection:"column", gap:12 }}>

          {/* Arrivals board */}
          {result.arrivals?.length > 0 && (
            <div style={{ background:C.surf, border:`1px solid ${C.border}`, borderRadius:14, padding:"18px 20px" }}>
              <div style={s.secTitle}>📋 ДОСКА ПРИЛЁТОВ BEN GURION · последние дни</div>
              <div style={{ display:"flex", flexDirection:"column", gap:6, marginBottom:12 }}>
                {result.arrivals.map((f, i) => (
                  <div key={i} style={{ display:"flex", alignItems:"center", gap:12, background:"#ffffff06", borderRadius:8, padding:"9px 12px" }}>
                    <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontWeight:600, minWidth:70, color:C.text }}>{f.flight}</span>
                    <span style={{ fontSize:12, color:C.muted, flex:1 }}>из TBS · {f.date}</span>
                    <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:11, color: f.status === "LANDED" ? C.green : C.yellow }}>
                      {f.status === "LANDED" ? "✅ ПРИЗЕМЛИЛСЯ" : f.status}
                    </span>
                  </div>
                ))}
              </div>
              <a href="https://www.tlvflights.com/en/arrivals/" target="_blank" rel="noreferrer"
                style={{ display:"block", textAlign:"center", padding:"9px", background:`${C.yellow}10`, border:`1px solid ${C.yellow}44`, borderRadius:8, color:C.yellow, textDecoration:"none", fontSize:11, fontFamily:"'IBM Plex Mono',monospace", letterSpacing:1 }}>
                📋 Открыть полную доску прилётов TLV ↗
              </a>
            </div>
          )}

          {/* Airlines */}
          {result.airlines?.length > 0 && (
            <div style={{ background:C.surf, border:`1px solid ${C.border}`, borderRadius:14, padding:"18px 20px" }}>
              <div style={s.secTitle}>✈️ АВИАКОМПАНИИ НА МАРШРУТЕ</div>
              <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
                {result.airlines.map((al, i) => {
                  const meta = AIRLINES_META[al.name] || {};
                  const col = meta.color || "#888";
                  return (
                    <div key={i} style={{ border:`1px solid ${col}33`, borderRadius:10, padding:"14px 16px" }}>
                      <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:6 }}>
                        <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontWeight:600, color:col, fontSize:15 }}>{meta.code || "??"}</span>
                        <span style={{ fontWeight:500, fontSize:15 }}>{al.name}</span>
                        <span style={{ marginLeft:"auto", fontSize:11, color: al.flying ? C.green : C.red, fontFamily:"'IBM Plex Mono',monospace" }}>
                          {al.flying ? "✅ ЛЕТИТ" : "❌ НЕ ЛЕТИТ"}
                        </span>
                      </div>
                      <div style={{ fontSize:12, color:"#888", marginBottom:6 }}>{meta.status}</div>
                      {al.evidence && <div style={{ fontSize:13, color:"#b0b8d0", marginBottom:8, lineHeight:1.5 }}>{al.evidence}</div>}
                      {meta.bagNote && <div style={{ fontSize:12, color:C.yellow, marginBottom:10 }}>🧳 {meta.bagNote}</div>}
                      {al.flying && al.price_per_person && (
                        <div style={{ background:"#ffffff06", borderRadius:8, padding:"10px 12px", marginBottom:10, display:"flex", alignItems:"center", gap:10 }}>
                          <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:20, color:C.text }}>${al.price_per_person}</span>
                          <span style={{ fontSize:12, color:C.muted }}>{al.fare} · 1 пассажир</span>
                          <span style={{ fontSize:11, color: al.bag_included ? C.green : C.yellow }}>
                            {al.bag_included ? "✓ багаж включён" : "✗ без багажа"}
                          </span>
                          {al.source_url && (
                            <a href={al.source_url} target="_blank" rel="noreferrer"
                              style={{ marginLeft:"auto", color:C.accent, textDecoration:"none", fontSize:11, fontFamily:"'IBM Plex Mono',monospace" }}>
                              офиц. сайт ↗
                            </a>
                          )}
                        </div>
                      )}
                      <div style={{ display:"flex", gap:8 }}>
                        {meta.bookingUrl && (
                          <a href={meta.bookingUrl} target="_blank" rel="noreferrer"
                            style={{ padding:"7px 12px", background:`${C.green}15`, border:`1px solid ${C.green}44`, borderRadius:7, color:C.green, textDecoration:"none", fontSize:11, fontFamily:"'IBM Plex Mono',monospace" }}>
                            🎫 Купить билет ↗
                          </a>
                        )}
                        {meta.baggageUrl && (
                          <a href={meta.baggageUrl} target="_blank" rel="noreferrer"
                            style={{ padding:"7px 12px", background:`${C.yellow}10`, border:`1px solid ${C.yellow}33`, borderRadius:7, color:C.yellow, textDecoration:"none", fontSize:11, fontFamily:"'IBM Plex Mono',monospace" }}>
                            🧳 Правила багажа ↗
                          </a>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Cost breakdown */}
          {result.best && (
            <div style={{ background:C.surf, border:`1px solid ${C.green}44`, borderRadius:14, padding:"18px 20px" }}>
              <div style={s.secTitle}>💰 ПОЛНАЯ СТОИМОСТЬ ПОЕЗДКИ</div>
              <div style={{ display:"flex", flexDirection:"column", gap:0 }}>
                {[
                  { label:`✈️ Билеты: ${pax} чел. × $${result.best.price_per_person}`, val:`$${result.best.tickets_subtotal}` },
                  result.best.extra_bags > 0 && { label:`🧳 Доп. чемоданов: ${result.best.extra_bags} × доплата`, val:`$${result.best.extra_bags_cost}` },
                  { label:`💼 Тролли (${trolleys} шт)`, val: result.best.trolleys_ok ? "✓ в норме" : "⚠️ уточнить" },
                ].filter(Boolean).map((row, i, arr) => (
                  <div key={i} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"10px 0", borderBottom:`1px solid ${C.border}` }}>
                    <span style={{ fontSize:13, color:"#b0b8d0" }}>{row.label}</span>
                    <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:13 }}>{row.val}</span>
                  </div>
                ))}
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"14px 0 4px" }}>
                  <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:14, color:C.green, fontWeight:600 }}>ИТОГО</span>
                  <div style={{ textAlign:"right" }}>
                    <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:22, color:C.green, fontWeight:600 }}>${result.best.total_usd}</div>
                    <div style={{ fontSize:12, color:C.muted, fontFamily:"'IBM Plex Mono',monospace" }}>≈ ₪{result.best.total_ils}</div>
                  </div>
                </div>
              </div>
              {result.best.trolleys_note && (
                <div style={{ fontSize:12, color:"#a0a870", marginTop:8, padding:"8px 10px", background:`${C.yellow}08`, borderRadius:6 }}>
                  💼 {result.best.trolleys_note}
                </div>
              )}
              {result.best.tip && (
                <div style={{ marginTop:10, padding:"10px 14px", background:`${C.accent}08`, border:`1px solid ${C.accent}22`, borderRadius:8, fontSize:13, color:"#90c8e0", lineHeight:1.5 }}>
                  💡 {result.best.tip}
                </div>
              )}
            </div>
          )}

          {/* Warning */}
          {result.warning && (
            <div style={{ background:`${C.yellow}08`, border:`1px solid ${C.yellow}33`, borderRadius:10, padding:"12px 16px", fontSize:13, color:"#c0a850", lineHeight:1.6 }}>
              ⚠️ {result.warning}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

const s = {
  lbl: { fontFamily:"'IBM Plex Mono',monospace", fontSize:9, letterSpacing:2, color:"#4a5270", marginBottom:5, display:"block" },
  secTitle: { fontFamily:"'IBM Plex Mono',monospace", fontSize:10, letterSpacing:2, color:"#00c8ff", marginBottom:12 },
  counter: { display:"flex", alignItems:"stretch" },
  cBtn: { background:"#080b12", border:"1px solid #1a2035", color:"#00c8ff", width:32, fontSize:16, cursor:"pointer", borderRadius:"7px 0 0 7px", fontFamily:"'IBM Plex Mono',monospace", padding:0 },
  cVal: { background:"#080b12", border:"1px solid #1a2035", borderLeft:"none", borderRight:"none", color:"#dde1f0", width:42, display:"flex", alignItems:"center", justifyContent:"center", fontSize:15, fontFamily:"'IBM Plex Mono',monospace" },
};
